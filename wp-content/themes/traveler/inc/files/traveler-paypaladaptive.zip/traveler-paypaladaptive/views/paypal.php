<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Payment
 *
 * Created by ShineTheme
 *
 */
?>
<div class="pm-info">
	<img class="pp-img" src="<?php echo Traveler_Paypal_Payment::get_inst()->pluginUrl; ?>/assets/img/paypal.png" alt="<?php st_the_language('paypal')?>">
	<p><?php st_the_language('you_will_be_redirected_to_payPal')?></p>
</div>