<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 12/15/2015
 * Time: 3:19 PM
 */


if (!class_exists('ST_Redsys_Payment_Gateway')) {
    class ST_Redsys_Payment_Gateway extends STAbstactPaymentGateway
    {
        static private $_ints;
        private $default_status = true;
        private $_gateway_id = 'st_redsys';

        private $gateway;

        function __construct()
        {
            add_filter('st_payment_gateway_st_redsys_name', array($this, 'get_name'));

        }

        function get_option_fields()
        {
            return array(
                [
                    'id' => 'customer_redsys',
                    'label' => esc_html__('Commerce number (FUC)', 'traveler-redsys'),
                    'type' => 'text',
                    'class' => 'input-sm',
                    'desc' => esc_html__('Commerce number (FUC) provided by your bank.', 'traveler-redsys'),
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'terminal_redsys',
                    'label' => esc_html__('Terminal number', 'traveler-redsys'),
                    'type' => 'text',
                    'class' => 'input-sm',
                    'desc' => esc_html__('Terminal number provided by your bank.', 'traveler-redsys'),
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'secure_key_redsys',
                    'label' => esc_html__('Secret Key', 'traveler-redsys'),
                    'type' => 'text',
                    'class' => 'input-sm',
                    'desc' => esc_html__('Encryption secret passphrase SHA-256 provided by your bank.', 'traveler-redsys'),
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'test_mode_redsys',
                    'label' => esc_html__('Test Mode', 'traveler-redsys'),
                    'type' => 'on-off',
                    'std' => 'on',
                    'desc' => esc_html__('Using for Redsys sanbox account', 'traveler-redsys'),
                    'section' => 'option_pmgateway'
                ],
            );
        }

        function _pre_checkout_validate()
        {
            return true;
        }

        public function setDefaultParams()
        {
            $merchant_id = st()->get_option('customer_redsys', '');
            $terminal = st()->get_option('terminal_redsys', '');
            $secure = st()->get_option('secure_key_redsys', '');

            $this->gateway = new \Buuum\Redsys($secure);
            $this->gateway->setMerchantcode($merchant_id);
            $this->gateway->setTerminal($terminal);

            $currency_codes = array(
                'EUR' => 978,
                'USD' => 840,
                'GBP' => 826,
                'JPY' => 392,
                'ARS' => 32,
                'CAD' => 124,
                'CLP' => 152,
                'COP' => 170,
                'INR' => 356,
                'MXN' => 484,
                'PEN' => 604,
                'CHF' => 756,
                'BRL' => 986,
                'BOB' => 937,
                'TRY' => 949,
            );
            $currentCurrency = TravelHelper::get_current_currency('name');
            $currencyCode = isset($currency_codes[$currentCurrency]) ? $currency_codes[$currentCurrency] : '';

            $this->gateway->setCurrency(978);
            $this->gateway->setTransactiontype('0');
            $this->gateway->setMethod('C');
        }

        public function getCartParams($order_id)
        {
            $this->setDefaultParams();
            $total = get_post_meta($order_id, 'total_price', true);

            $total = number_format($total, 2, '', '');
            $this->gateway->setAmount(13.45);
            $this->gateway->setOrder('ORD' . $order_id . '-' . rand(1234, 6789));
            $this->gateway->setNotification($this->get_return_url($order_id));
            $this->gateway->setUrlOk($this->get_return_url($order_id));
            $this->gateway->setUrlKo($this->get_return_url($order_id));

            $this->gateway->setTradeName(get_bloginfo('name'));
            $this->gateway->setTitular(get_post_meta($order_id, 'st_first_name', true) . ' ' . get_post_meta($order_id, 'st_last_name', true));
            $this->gateway->setProductDescription(get_the_title($order_id));
        }

        function do_checkout($order_id)
        {
            $this->setDefaultParams();
            $this->getCartParams($order_id);

            try {
                $type = 'test';
                if (st()->get_option('test_mode_redsys', 'on') == 'off') {
                    $type = 'live';
                }
                $form = $this->gateway->createForm($type);
                if (!empty($form)) {
                    return [
                        'status' => true,
                        'redirect_form' => $form
                    ];
                } else {
                    return [
                        'status' => false,
                        'message' => esc_html__('Your order has been created but we can not process', 'traveler-redsys'),
                    ];
                }
            } catch (\Exception $e) {
                return [
                    'status' => false,
                    'message' => sprintf(esc_html__('Your order has been created but we can not process. Error code: %s', 'traveler-redsys'), $e->getMessage())
                ];
            }
        }

        function check_complete_purchase($order_id)
        {
            if (isset($_REQUEST['txnid']) && isset($_REQUEST['mihpayid'])) {
                $order_id = $_REQUEST['udf1'];
                if ($order_id != '') {
                    $this->setDefaultParams();
                    try {
                        $statusOrder = get_post_meta($order_id, 'status', true);
                        $hash = $_REQUEST['hash'];
                        $status = $_REQUEST['status'];
                        $check = "$this->keySecret|$_REQUEST[status]||||||||||$_REQUEST[udf1]|$_REQUEST[email]|$_REQUEST[firstname]|$_REQUEST[productinfo]|$_REQUEST[amount]|$_REQUEST[txnid]|$this->keyID";
                        if ($_REQUEST['additionalCharges']) {
                            $check = $_REQUEST['additionalCharges'] . '|' . $check;
                        }
                        $checkhash = hash('sha512', $check);

                        if ('completed' !== $statusOrder) {
                            if ($hash == $checkhash) {
                                $status = strtolower($status);
                                if ('success' == $status) {
                                    if ('pending' == $statusOrder) {
                                        return [
                                            'status' => false
                                        ];
                                    } else {
                                        return [
                                            'status' => true
                                        ];
                                    }
                                } else if ('pending' == $status) {
                                    return [
                                        'status' => false
                                    ];
                                } else {
                                    return [
                                        'status' => false,
                                        'message' => __('Thank you for the order. However, the transaction has been declined.', 'traveler-redsys')
                                    ];
                                }
                            } else {
                                return [
                                    'status' => false,
                                    'message' => __('Security Error. Illegal access detected.', 'traveler-redsys')
                                ];
                            }
                        }
                    } catch (Exception $e) {
                        return [
                            'status' => false,
                            'message' => $e->getMessage()
                        ];
                    }
                }
            }
        }

        function is_check_complete_required()
        {
            return true;
        }

        function html()
        {
            echo Traveler_Redsys_Payment::get_inst()->loadTemplate('redsys');
        }

        function get_name()
        {
            return __('Redsys', 'traveler-redsys');
        }

        function get_default_status()
        {
            return $this->default_status;
        }

        function is_available($item_id = false)
        {
            if (st()->get_option('pm_gway_st_redsys_enable') == 'off') {
                return false;
            } else {
                if (!st()->get_option('payu_merchant_id')) {
                    return false;
                }
                if (!st()->get_option('payu_salt_key')) {
                    return false;
                }
            }

            if ($item_id) {
                $meta = get_post_meta($item_id, 'is_meta_payment_gateway_st_redsys', true);
                if ($meta == 'off') {
                    return false;
                }
            }

            return true;
        }

        function getGatewayId()
        {
            return $this->_gateway_id;
        }

        function get_logo()
        {
            return Traveler_Redsys_Payment::get_inst()->pluginUrl . 'assets/img/redsys.png';
        }

        static function instance()
        {
            if (!self::$_ints) {
                self::$_ints = new self();
            }

            return self::$_ints;
        }

        static function add_payment($payment)
        {
            $payment['st_redsys'] = self::instance();

            return $payment;
        }
    }

    add_filter('st_payment_gateways', array('ST_Redsys_Payment_Gateway', 'add_payment'));
}