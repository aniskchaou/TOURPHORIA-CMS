<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 12/16/2015
 * Time: 6:01 PM
 */
?>

<div class="pm-info">
	<p><?php _e('Take payments via Skrill (redirect method).','traveler-skrill')?></p>
</div>
