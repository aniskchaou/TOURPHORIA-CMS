<div class="pm-info">
    <p><?php echo __('Take payments via Mercado Pago payment (redirect method).', 'traveler-mercadopago') ?></p>
</div>