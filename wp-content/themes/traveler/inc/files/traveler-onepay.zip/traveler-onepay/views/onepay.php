<div class="pm-info">
    <p><?php echo __('Take payments via Onepay payment (redirect method).', 'traveler-onpay') ?></p>
</div>